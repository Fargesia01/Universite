from unifr_api_epuck import wrapper
from Setup import *
from Step_one import *
from Step_two import *
from Step_three import *
from Step_four import *

# MY_IP = '192.168.2.210'

MY_IP = '192.168.2.203'  # (#4191)

# could work sometimes
#MY_IP = '192.168.2.210'   # (#4210)

# turns, but doesn't recognizes green blocks
#MY_IP = '192.168.2.211'   # (#4211)

# didn't work
#MY_IP = '192.168.2.188'   # (#130)

robot = wrapper.get_robot(MY_IP)

def main():
	setup(robot)
	step_one(robot)
	#step_two(robot)
	#step_three(robot)
	#step_four(robot)

	robot.clean_up()

if __name__ == "__main__":
	main()
