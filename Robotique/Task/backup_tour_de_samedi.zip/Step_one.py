# run the code to generate IR sensor data 
from unifr_api_epuck import wrapper
import numpy as np
import os

# create directory
try: 
    os.mkdir("./img") 
except OSError as error: 
    print(error) 

MY_IP = '192.168.2.203'
robot = wrapper.get_robot(MY_IP)

robot.initiate_model()
robot.init_camera("./img")

#open file for writing
data = open("object_recog.csv", "w")

if data == None:
    print('Error opening data file!\n')
    quit

#write header in CSV file
data.write('step,x_center,y_center,width,height,conf,label\n')


# wait 3 seconds before starting
robot.sleep(3)

# enable front led (led 0)
robot.enable_front_led()
robot.enable_led(7)

robot.set_speed(-1,1)
step = 0

done = False

round = 0

round_black = [0, 0]
round_blue = [0, 0]
round_red = [0, 0]
round_green = [0, 0]

while robot.go_on() and not done:

    img = np.array(robot.get_camera())
    detections = robot.get_detection(img,0)
    outlier = False
    #Just save the detection
    for item in detections:
        data.write("{},{},{},{},{},{},{}\n".format(step,item.x_center,item.y_center,item.width,item.height,item.confidence,item.label))

        if len(detections) > 0:

            if (round < 2):
                if (item.label == "Black Block"):
                    round_black[round] = 1
                    robot.enable_led(7, 0, 0, 0)
                    #print ("Black block detected")

                elif (item.label == "Blue Block" and round_black[round]):
                    round_blue[round] = 1
                    robot.enable_led(7, 0, 0, 100)
                    #print ("Blue block detected")	

                elif (item.label == "Red Block" and round_red[round]):
                    round_green[round] = 1
                    robot.enable_led(7, 100, 0, 0)
                    #print ("Green block detected")

                if (round_black[0] and round_blue[0] and round_red[0] and round_green[0] and round == 0):
                    round = 1

                elif (round_black[1] and round_blue[1] and round_red[1] and round_green[1]):
                    round = 2

                print("Round 0 " + str(round_black[0]) + " " + str(round_blue[0]) + " " + str(round_red[0]) + " " + str(round_green[0]))
                print("Round 1 " + str(round_black[1]) + " " + str(round_blue[1]) + " " + str(round_red[1]) + " " + str(round_green[1]))

            elif (round ==2):
                print("Found green block after two turns!")
                robot.set_speed(0,0)
                robot.enable_led(7, 100, 0, 0)
                phase2 = True

robot.disable_all_led()
data.close()
robot.clean_up()
